from pydantic import BaseModel
from typing import Optional, List, Any, Dict


class InvestigateRequest(BaseModel):
    namespace: str = "all"
    context: Optional[str] = None  # kubeconfig context (cluster)


class PodInfo(BaseModel):
    name: str
    namespace: str
    status: str
    restart_count: int = 0
    reason: Optional[str] = None


class PodsPayload(BaseModel):
    healthy: bool
    total_pods: int
    problematic_pods: List[PodInfo] = []
    summary: str = ""


class LogsPayload(BaseModel):
    collected: bool
    pod_logs: Dict[str, str] = {}
    error_summary: str = ""


class EventsPayload(BaseModel):
    critical_events: List[Dict[str, Any]] = []
    warning_count: int = 0
    summary: str = ""


class DeploymentsPayload(BaseModel):
    healthy: bool
    unhealthy_deployments: List[Dict[str, Any]] = []
    summary: str = ""


class NetworkPayload(BaseModel):
    issues_found: bool
    findings: List[str] = []
    summary: str = ""


class InvestigationPayload(BaseModel):
    context: str = "default"
    namespace: str = "all"
    pods: Dict[str, Any] = {}
    logs: Dict[str, Any] = {}
    events: Dict[str, Any] = {}
    deployments: Dict[str, Any] = {}
    network: Dict[str, Any] = {}


class Diagnosis(BaseModel):
    root_cause: str
    explanation: str
    fix: str
    kubectl_command: str
    prevention: str
    confidence: int


class InvestigationResponse(BaseModel):
    status: str
    context: str = "default"
    investigation: Optional[InvestigationPayload] = None
    diagnosis: Optional[Diagnosis] = None
    error: Optional[str] = None


class ClusterContext(BaseModel):
    name: str
    cluster: str
    is_current: bool = False


class ClustersResponse(BaseModel):
    contexts: List[ClusterContext]
    current_context: Optional[str] = None
