from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from core.logger import log
from models.schemas import InvestigateRequest, InvestigationResponse, ClustersResponse
from services.investigation_service import run_investigation
from ai.root_cause_analyzer import analyze_and_diagnose
from kubernetes.kubectl_executor import get_kubeconfig_contexts


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("AI Kubernetes Agent starting up...")
    yield
    log.info("AI Kubernetes Agent shutting down.")


app = FastAPI(
    title="AI Kubernetes Agent",
    description="AI-powered Kubernetes troubleshooting agent",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "ai-kubernetes-agent"}


@app.get("/clusters", response_model=ClustersResponse)
async def list_clusters():
    """
    List all Kubernetes contexts (clusters) from the local kubeconfig.
    This powers the cluster selector in the frontend.
    """
    log.info("Fetching kubeconfig contexts...")
    result = get_kubeconfig_contexts()

    if not result["success"]:
        log.warning(f"Could not list contexts: {result.get('error', '')}")
        return ClustersResponse(contexts=[], current_context=None)

    from models.schemas import ClusterContext
    contexts = [
        ClusterContext(
            name=ctx["name"],
            cluster=ctx["cluster"],
            is_current=ctx["is_current"],
        )
        for ctx in result["contexts"]
    ]

    return ClustersResponse(
        contexts=contexts,
        current_context=result.get("current_context"),
    )


@app.post("/investigate", response_model=InvestigationResponse)
async def investigate(request: InvestigateRequest):
    """
    Full Kubernetes investigation + AI diagnosis.

    Flow:
    1. Collect Kubernetes evidence (pods, logs, events, deployments, network)
    2. Send to AI agent for root cause analysis
    3. Return structured diagnosis
    """
    context = request.context
    namespace = request.namespace

    log.info(f"Investigation requested | context={context} | namespace={namespace}")

    # Step 1: Run Kubernetes investigation
    try:
        investigation = run_investigation(namespace=namespace, context=context)
    except Exception as e:
        log.error(f"Investigation failed: {e}")
        return InvestigationResponse(
            status="error",
            context=context or "default",
            error=f"Kubernetes investigation failed: {str(e)}. "
                  f"Please verify: kubeconfig path, cluster access, and kubectl permissions.",
        )

    # Step 2: AI reasoning
    try:
        diagnosis = await analyze_and_diagnose(investigation)
    except Exception as e:
        log.error(f"AI analysis failed: {e}")
        return InvestigationResponse(
            status="error",
            context=context or "default",
            investigation=investigation,
            error=f"AI analysis failed: {str(e)}",
        )

    log.info("Investigation + diagnosis complete. Returning response.")

    return InvestigationResponse(
        status="success",
        context=context or "default",
        investigation=investigation,
        diagnosis=diagnosis,
    )
