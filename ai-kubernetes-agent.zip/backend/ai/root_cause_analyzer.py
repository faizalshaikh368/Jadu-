from typing import Dict, Any
from ai.prompt_builder import SYSTEM_PROMPT, build_investigation_prompt
from ai.llm_client import LLMClient, parse_llm_json
from core.logger import log


FALLBACK_DIAGNOSIS = {
    "root_cause": "Unable to determine root cause",
    "explanation": "The AI analysis could not complete. Please check your OpenRouter API key and try again.",
    "fix": "Review the investigation data manually and check pod logs directly with kubectl.",
    "kubectl_command": "kubectl get pods -A\nkubectl describe pod <pod-name> -n <namespace>",
    "prevention": "Ensure monitoring and alerting is configured for your cluster.",
    "confidence": 0,
}

HEALTHY_DIAGNOSIS = {
    "root_cause": "No critical issues detected",
    "explanation": "All pods, deployments, and services appear healthy. No errors found in logs or events.",
    "fix": "No action required. Cluster is operating normally.",
    "kubectl_command": "kubectl get pods -A  # verify cluster health",
    "prevention": "Continue regular monitoring with Prometheus and Grafana.",
    "confidence": 95,
}


async def analyze_and_diagnose(investigation: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main AI reasoning pipeline.
    Takes investigation payload → returns root cause + fix + confidence.

    This is the "Senior SRE" brain of the system.
    """
    # Quick check: is the cluster actually healthy?
    pods = investigation.get("pods", {})
    events = investigation.get("events", {})
    deployments = investigation.get("deployments", {})
    network = investigation.get("network", {})

    has_issues = (
        not pods.get("healthy", True)
        or not deployments.get("healthy", True)
        or network.get("issues_found", False)
        or len(events.get("critical_events", [])) > 0
    )

    if not has_issues and pods.get("total_pods", 0) > 0:
        log.info("Cluster appears healthy — skipping LLM call.")
        return HEALTHY_DIAGNOSIS

    # Build structured prompt
    user_prompt = build_investigation_prompt(investigation)

    log.info("Sending investigation to LLM for root cause analysis...")

    # Call LLM
    client = LLMClient()
    result = await client.chat_safe(SYSTEM_PROMPT, user_prompt)

    if not result["success"] or not result["content"]:
        log.warning(f"LLM analysis failed: {result.get('error', 'unknown')}")
        fallback = dict(FALLBACK_DIAGNOSIS)
        fallback["explanation"] = result.get("error", fallback["explanation"])
        return fallback

    # Parse JSON response
    diagnosis = parse_llm_json(result["content"])

    if not diagnosis:
        log.warning("LLM response could not be parsed as JSON. Using fallback.")
        return FALLBACK_DIAGNOSIS

    # Validate required fields + fill defaults
    required_fields = ["root_cause", "explanation", "fix", "kubectl_command", "prevention", "confidence"]
    for field in required_fields:
        if field not in diagnosis:
            diagnosis[field] = FALLBACK_DIAGNOSIS[field]

    # Clamp confidence to 0-100
    try:
        diagnosis["confidence"] = max(0, min(100, int(diagnosis["confidence"])))
    except (ValueError, TypeError):
        diagnosis["confidence"] = 50

    log.info(f"Diagnosis complete | root_cause={diagnosis['root_cause'][:60]} | confidence={diagnosis['confidence']}%")

    return diagnosis
