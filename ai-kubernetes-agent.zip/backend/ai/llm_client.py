import json
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from core.config import get_settings
from core.logger import log


OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


class LLMClient:
    def __init__(self):
        self.settings = get_settings()
        self.api_key = self.settings.openrouter_api_key
        self.model = self.settings.openrouter_model

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError)),
        reraise=True,
    )
    async def chat(self, system_prompt: str, user_prompt: str) -> dict:
        """
        Send a prompt to OpenRouter and return the parsed response.
        Retries on network failures. Returns structured dict.
        """
        if not self.api_key:
            raise ValueError(
                "OPENROUTER_API_KEY is not set. "
                "Please add it to your .env file."
            )

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://ai-kubernetes-agent.local",
            "X-Title": "AI Kubernetes Agent",
        }

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.1,  # Low temp for deterministic, factual responses
            "max_tokens": 1500,
        }

        log.info(f"Calling OpenRouter | model={self.model}")

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{OPENROUTER_BASE_URL}/chat/completions",
                headers=headers,
                json=payload,
            )

            if response.status_code != 200:
                error_body = response.text
                log.error(f"OpenRouter API error {response.status_code}: {error_body}")
                raise httpx.HTTPStatusError(
                    f"OpenRouter returned {response.status_code}: {error_body}",
                    request=response.request,
                    response=response,
                )

            data = response.json()
            content = data["choices"][0]["message"]["content"]
            log.info("OpenRouter response received successfully.")
            return {"success": True, "content": content}

    async def chat_safe(self, system_prompt: str, user_prompt: str) -> dict:
        """
        Wrapper around chat() that never raises.
        Returns error dict on failure for graceful degradation.
        """
        try:
            return await self.chat(system_prompt, user_prompt)
        except ValueError as e:
            log.error(f"LLM config error: {e}")
            return {"success": False, "error": str(e), "content": None}
        except httpx.TimeoutException:
            log.error("OpenRouter request timed out.")
            return {"success": False, "error": "LLM request timed out. Try again.", "content": None}
        except httpx.HTTPStatusError as e:
            log.error(f"OpenRouter HTTP error: {e}")
            return {"success": False, "error": f"LLM API error: {str(e)}", "content": None}
        except Exception as e:
            log.error(f"Unexpected LLM error: {e}")
            return {"success": False, "error": f"Unexpected error: {str(e)}", "content": None}


def parse_llm_json(content: str) -> dict:
    """
    Parse JSON from LLM response.
    Handles markdown code blocks and whitespace.
    """
    if not content:
        return {}

    # Strip markdown fences if present
    cleaned = content.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        cleaned = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Try to extract JSON between first { and last }
        start = cleaned.find("{")
        end = cleaned.rfind("}") + 1
        if start != -1 and end > start:
            try:
                return json.loads(cleaned[start:end])
            except json.JSONDecodeError:
                pass

    log.warning("Could not parse LLM response as JSON")
    return {}
