import json
from typing import Dict, Any


SYSTEM_PROMPT = """You are a Senior Kubernetes Site Reliability Engineer (SRE) with 10+ years of experience.

You are an expert at:
- Diagnosing Kubernetes failures from pod states, logs, events, and deployment conditions
- Correlating multiple signals to find the true root cause (not just symptoms)
- Writing clear, actionable fixes for engineers of all skill levels
- Generating precise kubectl commands to resolve issues
- Explaining complex failures in plain language

Your analysis must be:
- Evidence-based: cite specific log lines, events, or pod states
- Decisive: commit to a root cause, not a list of possibilities
- Actionable: every fix must have a concrete kubectl command
- Beginner-friendly: explain WHY the fix works

You MUST respond ONLY with valid JSON in this exact structure:
{
  "root_cause": "One clear sentence stating the root cause",
  "explanation": "2-3 sentences explaining what happened and why, citing evidence from the investigation data",
  "fix": "Step-by-step fix in plain language",
  "kubectl_command": "The exact kubectl command(s) to fix the issue",
  "prevention": "One clear recommendation to prevent this in future",
  "confidence": <integer 0-100>
}

Confidence scoring guide:
- 90-100: Clear error in logs + matching pod state + confirming events
- 70-89: Strong signals but some ambiguity
- 50-69: Partial evidence, multiple possible causes
- Below 50: Insufficient data to determine cause

If the cluster appears healthy, set root_cause to "No critical issues detected" and confidence to 95."""


def build_investigation_prompt(investigation: Dict[str, Any]) -> str:
    """
    Build a structured prompt from the investigation payload.
    Formats evidence clearly for LLM reasoning.
    """
    pods = investigation.get("pods", {})
    logs = investigation.get("logs", {})
    events = investigation.get("events", {})
    deployments = investigation.get("deployments", {})
    network = investigation.get("network", {})
    context = investigation.get("context", "unknown")
    namespace = investigation.get("namespace", "all")

    prompt_parts = [
        f"## Kubernetes Investigation Report",
        f"**Cluster Context:** {context}",
        f"**Namespace:** {namespace}",
        "",
        "---",
        "",
        "## 1. Pod Status",
        f"Healthy: {pods.get('healthy', 'unknown')}",
        f"Total Pods: {pods.get('total_pods', 0)}",
        f"Summary: {pods.get('summary', 'N/A')}",
    ]

    problematic = pods.get("problematic_pods", [])
    if problematic:
        prompt_parts.append("\nProblematic Pods:")
        for p in problematic[:10]:
            prompt_parts.append(
                f"  - {p['name']} [{p['namespace']}]: status={p['status']}, restarts={p.get('restart_count', 0)}"
            )

    prompt_parts += [
        "",
        "## 2. Log Evidence",
        f"Logs collected: {logs.get('collected', False)}",
    ]

    pod_logs = logs.get("pod_logs", {})
    if pod_logs:
        for pod_name, log_content in list(pod_logs.items())[:3]:
            prompt_parts.append(f"\n### Logs for {pod_name}:")
            prompt_parts.append(log_content[:800] if log_content else "No logs available")

    prompt_parts += [
        "",
        "## 3. Kubernetes Events",
        f"Summary: {events.get('summary', 'N/A')}",
        f"Total Warnings: {events.get('warning_count', 0)}",
    ]

    critical_events = events.get("critical_events", [])
    if critical_events:
        prompt_parts.append("\nCritical Events:")
        for evt in critical_events[:10]:
            prompt_parts.append(
                f"  [{evt.get('type', '?')}] {evt.get('reason', '?')} | {evt.get('object', '?')}: {evt.get('message', '')[:150]}"
            )

    prompt_parts += [
        "",
        "## 4. Deployment Health",
        f"Healthy: {deployments.get('healthy', 'unknown')}",
        f"Summary: {deployments.get('summary', 'N/A')}",
    ]

    unhealthy_deps = deployments.get("unhealthy_deployments", [])
    if unhealthy_deps:
        prompt_parts.append("\nUnhealthy Deployments:")
        for dep in unhealthy_deps[:5]:
            prompt_parts.append(
                f"  - {dep['name']} [{dep['namespace']}]: {dep.get('issue', '')} | ready={dep.get('ready', '?')}"
            )

    prompt_parts += [
        "",
        "## 5. Networking Findings",
        f"Issues Found: {network.get('issues_found', False)}",
        f"Summary: {network.get('summary', 'N/A')}",
    ]

    net_findings = network.get("findings", [])
    if net_findings:
        prompt_parts.append("\nNetwork Issues:")
        for f in net_findings[:5]:
            prompt_parts.append(f"  - {f}")

    prompt_parts += [
        "",
        "---",
        "",
        "Based on this Kubernetes investigation data, provide your diagnosis as a Senior SRE.",
        "Correlate the evidence across all sections. Do not just summarize — find the ROOT CAUSE.",
        "Respond ONLY with the JSON structure specified in your instructions.",
    ]

    return "\n".join(prompt_parts)
