from pydantic_settings import BaseSettings
from functools import lru_cache
import os


class Settings(BaseSettings):
    openrouter_api_key: str = ""
    openrouter_model: str = "deepseek/deepseek-r1-0528"
    kubeconfig_path: str = "~/.kube/config"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
