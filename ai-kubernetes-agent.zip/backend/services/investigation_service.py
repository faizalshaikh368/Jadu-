from typing import Optional
from kubernetes.pod_inspector import inspect_pods
from kubernetes.logs_collector import collect_logs
from kubernetes.events_analyzer import analyze_events
from kubernetes.deployment_inspector import inspect_deployments
from kubernetes.network_inspector import inspect_network
from core.logger import log


def run_investigation(
    namespace: str = "all",
    context: Optional[str] = None,
) -> dict:
    """
    Orchestrate all Kubernetes investigation steps.
    Returns a single structured investigation payload.
    Acts like a junior DevOps engineer collecting evidence.
    """
    log.info(f"Starting Kubernetes investigation | context={context} | namespace={namespace}")

    # Step 1: Check Pods
    log.info("Step 1/5: Inspecting pods...")
    pods = inspect_pods(namespace=namespace, context=context)

    # Step 2: Collect Logs (only for problematic pods)
    log.info("Step 2/5: Collecting logs...")
    problematic = pods.get("problematic_pods", [])
    logs = collect_logs(problematic_pods=problematic, context=context)

    # Step 3: Analyze Events
    log.info("Step 3/5: Analyzing events...")
    events = analyze_events(namespace=namespace, context=context)

    # Step 4: Inspect Deployments
    log.info("Step 4/5: Inspecting deployments...")
    deployments = inspect_deployments(namespace=namespace, context=context)

    # Step 5: Check Networking
    log.info("Step 5/5: Checking network...")
    network = inspect_network(namespace=namespace, context=context)

    log.info("Investigation complete. Returning payload.")

    return {
        "context": context or "default",
        "namespace": namespace,
        "pods": pods,
        "logs": logs,
        "events": events,
        "deployments": deployments,
        "network": network,
    }
