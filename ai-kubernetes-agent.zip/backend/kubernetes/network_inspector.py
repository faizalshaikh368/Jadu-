from typing import Optional
from kubernetes.kubectl_executor import run_kubectl
from core.logger import log


def inspect_network(namespace: str = "all", context: Optional[str] = None) -> dict:
    """
    Inspect Kubernetes services and endpoints for network issues.
    Detects missing endpoints, selector mismatches.
    """
    ns_flag = "-A" if namespace == "all" else f"-n {namespace}"
    findings = []

    # Get services
    svc_result = run_kubectl(f"get svc {ns_flag} --no-headers", context=context)
    ep_result = run_kubectl(f"get endpoints {ns_flag} --no-headers", context=context)

    if not svc_result["success"]:
        return {
            "issues_found": False,
            "findings": [f"Could not retrieve services: {svc_result['stderr']}"],
            "summary": "Network inspection failed.",
        }

    # Parse endpoints to find services with no endpoints
    endpoints_without_targets = []
    if ep_result["success"]:
        for line in ep_result["stdout"].splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue

            if namespace == "all":
                ep_ns = parts[0]
                ep_name = parts[1]
                ep_addresses = parts[2] if len(parts) > 2 else "<none>"
            else:
                ep_ns = namespace
                ep_name = parts[0]
                ep_addresses = parts[1] if len(parts) > 1 else "<none>"

            if ep_addresses in ("<none>", ""):
                if ep_name not in ("kubernetes",):  # skip system services
                    endpoints_without_targets.append({
                        "service": ep_name,
                        "namespace": ep_ns,
                        "issue": "No endpoints — possible selector mismatch or no matching pods",
                    })
                    findings.append(
                        f"Service '{ep_name}' in '{ep_ns}' has no endpoints. "
                        f"Check pod labels match service selector."
                    )

    # Count services
    svc_lines = [l for l in svc_result["stdout"].splitlines() if l.strip()]
    total_services = len(svc_lines)

    issues_found = len(findings) > 0

    summary = (
        f"Network looks healthy. {total_services} services found."
        if not issues_found
        else f"Found {len(findings)} network issue(s) across {total_services} services."
    )

    log.info(f"Network inspection: {summary}")

    return {
        "issues_found": issues_found,
        "total_services": total_services,
        "services_without_endpoints": endpoints_without_targets,
        "findings": findings,
        "summary": summary,
    }
