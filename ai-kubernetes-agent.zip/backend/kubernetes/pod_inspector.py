from typing import Optional
from kubernetes.kubectl_executor import run_kubectl
from core.logger import log

UNHEALTHY_STATUSES = {
    "CrashLoopBackOff",
    "ImagePullBackOff",
    "ErrImagePull",
    "Pending",
    "Error",
    "OOMKilled",
    "CreateContainerError",
    "ContainerCreating",
    "Terminating",
    "Unknown",
}


def inspect_pods(namespace: str = "all", context: Optional[str] = None) -> dict:
    """
    Get pod status across the cluster.
    Returns structured JSON with healthy/unhealthy pod info.
    """
    ns_flag = "-A" if namespace == "all" else f"-n {namespace}"
    result = run_kubectl(
        f"get pods {ns_flag} --no-headers -o wide",
        context=context,
    )

    if not result["success"]:
        return {
            "healthy": False,
            "total_pods": 0,
            "problematic_pods": [],
            "summary": f"Failed to get pods: {result['stderr']}",
            "raw_error": result["stderr"],
        }

    lines = result["stdout"].splitlines()
    if not lines or result["stdout"] == "No resources found.":
        return {
            "healthy": True,
            "total_pods": 0,
            "problematic_pods": [],
            "summary": "No pods found in cluster.",
        }

    total = 0
    problematic = []

    for line in lines:
        parts = line.split()
        if len(parts) < 4:
            continue

        total += 1

        # Column layout (with -A): NAMESPACE NAME READY STATUS RESTARTS AGE ...
        # Column layout (without -A): NAME READY STATUS RESTARTS AGE ...
        if namespace == "all":
            pod_namespace = parts[0]
            pod_name = parts[1]
            status = parts[3]
            restarts_raw = parts[4] if len(parts) > 4 else "0"
        else:
            pod_namespace = namespace
            pod_name = parts[0]
            status = parts[2]
            restarts_raw = parts[3] if len(parts) > 3 else "0"

        # Parse restart count (may be "3 (2m ago)" format)
        try:
            restarts = int(restarts_raw.split("(")[0].strip())
        except ValueError:
            restarts = 0

        is_problematic = (
            any(s in status for s in UNHEALTHY_STATUSES)
            or restarts > 3
        )

        if is_problematic:
            problematic.append({
                "name": pod_name,
                "namespace": pod_namespace,
                "status": status,
                "restart_count": restarts,
                "reason": status,
            })

    healthy = len(problematic) == 0
    summary = (
        f"All {total} pods healthy."
        if healthy
        else f"Found {len(problematic)} problematic pod(s) out of {total} total."
    )

    log.info(f"Pod inspection: {summary}")

    return {
        "healthy": healthy,
        "total_pods": total,
        "problematic_pods": problematic,
        "summary": summary,
    }
