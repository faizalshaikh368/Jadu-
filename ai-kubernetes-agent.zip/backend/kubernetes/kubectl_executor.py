import subprocess
import shlex
from typing import Optional
from core.logger import log


def run_kubectl(
    command: str,
    context: Optional[str] = None,
    timeout: int = 30,
) -> dict:
    """
    Safely execute a kubectl command and return structured output.

    Args:
        command: The kubectl command (without 'kubectl' prefix)
        context: Optional kubeconfig context (cluster name)
        timeout: Seconds before giving up

    Returns:
        {"success": bool, "stdout": str, "stderr": str, "command": str}
    """
    ctx_flag = f"--context={context}" if context else ""
    full_command = f"kubectl {ctx_flag} {command}".strip()
    full_command = " ".join(full_command.split())  # normalize spaces

    log.info(f"Running: {full_command}")

    try:
        result = subprocess.run(
            shlex.split(full_command),
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        success = result.returncode == 0

        if not success:
            log.warning(f"kubectl failed (exit {result.returncode}): {result.stderr.strip()}")

        return {
            "success": success,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
            "command": full_command,
            "return_code": result.returncode,
        }

    except subprocess.TimeoutExpired:
        log.error(f"kubectl command timed out after {timeout}s: {full_command}")
        return {
            "success": False,
            "stdout": "",
            "stderr": f"Command timed out after {timeout} seconds.",
            "command": full_command,
            "return_code": -1,
        }
    except FileNotFoundError:
        log.error("kubectl not found in PATH")
        return {
            "success": False,
            "stdout": "",
            "stderr": "kubectl not found. Please install kubectl and ensure it's in PATH.",
            "command": full_command,
            "return_code": -1,
        }
    except Exception as e:
        log.error(f"Unexpected error running kubectl: {e}")
        return {
            "success": False,
            "stdout": "",
            "stderr": str(e),
            "command": full_command,
            "return_code": -1,
        }


def get_kubeconfig_contexts() -> dict:
    """
    List all available kubeconfig contexts (clusters).
    Returns structured list of contexts.
    """
    result = run_kubectl("config get-contexts -o name")
    if not result["success"]:
        # Try without context flag
        return {"success": False, "contexts": [], "error": result["stderr"]}

    contexts_raw = [c.strip() for c in result["stdout"].splitlines() if c.strip()]

    # Get current context
    current_result = run_kubectl("config current-context")
    current = current_result["stdout"].strip() if current_result["success"] else ""

    contexts = []
    for ctx in contexts_raw:
        contexts.append({
            "name": ctx,
            "cluster": ctx,
            "is_current": ctx == current,
        })

    return {
        "success": True,
        "contexts": contexts,
        "current_context": current,
    }
