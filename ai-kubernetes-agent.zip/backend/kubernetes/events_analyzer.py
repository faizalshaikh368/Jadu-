from typing import Optional
from kubernetes.kubectl_executor import run_kubectl
from core.logger import log

CRITICAL_REASONS = {
    "FailedScheduling",
    "BackOff",
    "CrashLoopBackOff",
    "FailedMount",
    "FailedPull",
    "ErrImagePull",
    "Unhealthy",
    "OOMKilling",
    "Evicted",
    "FailedCreate",
    "ImagePullBackOff",
    "FailedAttachVolume",
    "NodeNotReady",
}


def analyze_events(namespace: str = "all", context: Optional[str] = None) -> dict:
    """
    Read Kubernetes events and return critical findings.
    """
    ns_flag = "-A" if namespace == "all" else f"-n {namespace}"
    result = run_kubectl(
        f"get events {ns_flag} --sort-by=.lastTimestamp --no-headers",
        context=context,
    )

    if not result["success"]:
        return {
            "critical_events": [],
            "warning_count": 0,
            "summary": f"Failed to get events: {result['stderr']}",
        }

    lines = result["stdout"].splitlines()
    if not lines:
        return {
            "critical_events": [],
            "warning_count": 0,
            "summary": "No events found.",
        }

    critical_events = []
    warning_count = 0

    for line in lines:
        parts = line.split()
        if len(parts) < 5:
            continue

        # Events format: LAST SEEN | TYPE | REASON | OBJECT | MESSAGE
        # With -A: NAMESPACE | LAST SEEN | TYPE | REASON | OBJECT | MESSAGE
        try:
            if namespace == "all":
                event_type = parts[2] if len(parts) > 2 else ""
                reason = parts[3] if len(parts) > 3 else ""
                obj = parts[4] if len(parts) > 4 else ""
                message = " ".join(parts[5:]) if len(parts) > 5 else ""
                ns = parts[0]
            else:
                event_type = parts[1] if len(parts) > 1 else ""
                reason = parts[2] if len(parts) > 2 else ""
                obj = parts[3] if len(parts) > 3 else ""
                message = " ".join(parts[4:]) if len(parts) > 4 else ""
                ns = namespace
        except IndexError:
            continue

        if event_type == "Warning":
            warning_count += 1

        if reason in CRITICAL_REASONS or event_type == "Warning":
            critical_events.append({
                "namespace": ns,
                "type": event_type,
                "reason": reason,
                "object": obj,
                "message": message[:200],
            })

    # Keep most recent 20 critical events
    critical_events = critical_events[-20:]

    summary = (
        f"No critical events found." if not critical_events
        else f"Found {len(critical_events)} critical event(s), {warning_count} warnings total."
    )

    log.info(f"Events analysis: {summary}")

    return {
        "critical_events": critical_events,
        "warning_count": warning_count,
        "summary": summary,
    }
