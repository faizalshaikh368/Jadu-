from typing import Optional
from kubernetes.kubectl_executor import run_kubectl
from core.logger import log


def inspect_deployments(namespace: str = "all", context: Optional[str] = None) -> dict:
    """
    Inspect deployment health across the cluster.
    Detects unavailable replicas and rollout failures.
    """
    ns_flag = "-A" if namespace == "all" else f"-n {namespace}"
    result = run_kubectl(
        f"get deployments {ns_flag} --no-headers",
        context=context,
    )

    if not result["success"]:
        return {
            "healthy": False,
            "unhealthy_deployments": [],
            "summary": f"Failed to get deployments: {result['stderr']}",
        }

    lines = result["stdout"].splitlines()
    if not lines or result["stdout"] == "No resources found.":
        return {
            "healthy": True,
            "unhealthy_deployments": [],
            "summary": "No deployments found.",
        }

    unhealthy = []

    for line in lines:
        parts = line.split()
        if len(parts) < 5:
            continue

        try:
            if namespace == "all":
                ns = parts[0]
                name = parts[1]
                ready = parts[2]   # e.g. "1/3"
                up_to_date = parts[3]
                available = parts[4]
            else:
                ns = namespace
                name = parts[0]
                ready = parts[1]
                up_to_date = parts[2]
                available = parts[3]
        except IndexError:
            continue

        # Parse ready replicas
        try:
            ready_parts = ready.split("/")
            ready_count = int(ready_parts[0])
            desired_count = int(ready_parts[1])
            is_healthy = ready_count == desired_count and desired_count > 0
        except (ValueError, IndexError):
            is_healthy = True  # can't tell, assume ok
            ready_count = 0
            desired_count = 0

        if not is_healthy:
            unhealthy.append({
                "name": name,
                "namespace": ns,
                "ready": ready,
                "up_to_date": up_to_date,
                "available": available,
                "issue": f"Only {ready_count}/{desired_count} replicas ready",
            })

    healthy = len(unhealthy) == 0
    summary = (
        "All deployments healthy."
        if healthy
        else f"Found {len(unhealthy)} unhealthy deployment(s)."
    )

    log.info(f"Deployment inspection: {summary}")

    return {
        "healthy": healthy,
        "unhealthy_deployments": unhealthy,
        "summary": summary,
    }
