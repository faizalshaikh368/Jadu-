from typing import Optional, List, Dict
from kubernetes.kubectl_executor import run_kubectl
from core.logger import log

ERROR_KEYWORDS = [
    "exception",
    "error",
    "fatal",
    "failed",
    "panic",
    "crash",
    "connection refused",
    "timeout",
    "oomkilled",
    "missing",
    "not found",
    "cannot",
    "unable",
    "unauthorized",
    "permission denied",
    "env",
    "database",
    "secret",
    "config",
]

MAX_LOG_LINES = 50


def collect_logs(
    problematic_pods: List[Dict],
    context: Optional[str] = None,
) -> dict:
    """
    Fetch and filter logs for problematic pods.
    Focuses on error lines to keep output concise.
    """
    if not problematic_pods:
        return {
            "collected": False,
            "pod_logs": {},
            "error_summary": "No problematic pods to collect logs for.",
        }

    pod_logs = {}
    error_summary_parts = []

    for pod in problematic_pods[:5]:  # limit to 5 pods max
        pod_name = pod["name"]
        namespace = pod["namespace"]

        log.info(f"Collecting logs for pod: {pod_name} in {namespace}")

        # Try current logs first
        result = run_kubectl(
            f"logs {pod_name} -n {namespace} --tail=100 --previous",
            context=context,
            timeout=15,
        )

        if not result["success"] or not result["stdout"]:
            # Try without --previous
            result = run_kubectl(
                f"logs {pod_name} -n {namespace} --tail=100",
                context=context,
                timeout=15,
            )

        if result["success"] and result["stdout"]:
            filtered = _filter_error_lines(result["stdout"])
            pod_logs[pod_name] = filtered

            if filtered:
                error_summary_parts.append(
                    f"{pod_name}: {filtered[:200]}..."
                )
        else:
            pod_logs[pod_name] = f"Could not retrieve logs: {result['stderr']}"

    error_summary = "\n".join(error_summary_parts) if error_summary_parts else "No error lines found in logs."

    return {
        "collected": bool(pod_logs),
        "pod_logs": pod_logs,
        "error_summary": error_summary,
    }


def _filter_error_lines(log_text: str) -> str:
    """Keep only lines containing error-related keywords."""
    lines = log_text.splitlines()
    error_lines = []

    for line in lines:
        line_lower = line.lower()
        if any(kw in line_lower for kw in ERROR_KEYWORDS):
            error_lines.append(line.strip())

    # Return filtered or last N lines if nothing matched
    if error_lines:
        return "\n".join(error_lines[:MAX_LOG_LINES])
    else:
        return "\n".join(lines[-20:])  # last 20 lines as fallback
