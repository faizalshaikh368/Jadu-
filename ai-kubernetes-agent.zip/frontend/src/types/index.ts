export interface ClusterContext {
  name: string;
  cluster: string;
  is_current: boolean;
}

export interface ClustersResponse {
  contexts: ClusterContext[];
  current_context: string | null;
}

export interface PodInfo {
  name: string;
  namespace: string;
  status: string;
  restart_count: number;
  reason?: string;
}

export interface Diagnosis {
  root_cause: string;
  explanation: string;
  fix: string;
  kubectl_command: string;
  prevention: string;
  confidence: number;
}

export interface InvestigationPayload {
  context: string;
  namespace: string;
  pods: {
    healthy: boolean;
    total_pods: number;
    problematic_pods: PodInfo[];
    summary: string;
  };
  logs: {
    collected: boolean;
    pod_logs: Record<string, string>;
    error_summary: string;
  };
  events: {
    critical_events: Array<{
      namespace: string;
      type: string;
      reason: string;
      object: string;
      message: string;
    }>;
    warning_count: number;
    summary: string;
  };
  deployments: {
    healthy: boolean;
    unhealthy_deployments: Array<{
      name: string;
      namespace: string;
      ready: string;
      issue: string;
    }>;
    summary: string;
  };
  network: {
    issues_found: boolean;
    findings: string[];
    summary: string;
  };
}

export interface InvestigationResponse {
  status: "success" | "error";
  context: string;
  investigation?: InvestigationPayload;
  diagnosis?: Diagnosis;
  error?: string;
}

export type InvestigationStep =
  | "pods"
  | "logs"
  | "events"
  | "deployments"
  | "network"
  | "ai"
  | "done";
