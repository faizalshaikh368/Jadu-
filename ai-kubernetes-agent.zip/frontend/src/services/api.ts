import axios from "axios";
import type { ClustersResponse, InvestigationResponse } from "@/types";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

const api = axios.create({
  baseURL: API_BASE,
  timeout: 120000, // 2 min — investigations take time
});

export async function fetchClusters(): Promise<ClustersResponse> {
  const res = await api.get<ClustersResponse>("/clusters");
  return res.data;
}

export async function runInvestigation(
  context: string | null,
  namespace: string = "all"
): Promise<InvestigationResponse> {
  const res = await api.post<InvestigationResponse>("/investigate", {
    context,
    namespace,
  });
  return res.data;
}

export async function checkHealth(): Promise<boolean> {
  try {
    const res = await api.get("/health");
    return res.data?.status === "healthy";
  } catch {
    return false;
  }
}
