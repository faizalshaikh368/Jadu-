import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Kubernetes Agent",
  description: "AI-powered Kubernetes troubleshooting — Senior SRE in your browser",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
