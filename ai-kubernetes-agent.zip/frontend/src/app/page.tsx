"use client";

import { useState, useEffect, useCallback } from "react";
import type {
  ClusterContext,
  InvestigationResponse,
  InvestigationStep,
} from "@/types";
import { fetchClusters, runInvestigation } from "@/services/api";

// ─── Step definitions ────────────────────────────────────────────────────────

const STEPS: { id: InvestigationStep; label: string; duration: number }[] = [
  { id: "pods", label: "Checking Pods", duration: 1200 },
  { id: "logs", label: "Reading Logs", duration: 1500 },
  { id: "events", label: "Analyzing Events", duration: 1000 },
  { id: "deployments", label: "Inspecting Deployments", duration: 1000 },
  { id: "network", label: "Checking Networking", duration: 1000 },
  { id: "ai", label: "AI Reasoning (Senior SRE)", duration: 3000 },
  { id: "done", label: "Root Cause Found", duration: 0 },
];

// ─── Sub-components ──────────────────────────────────────────────────────────

function StatusDot({ ok }: { ok: boolean }) {
  return (
    <span
      className="inline-block w-2 h-2 rounded-full"
      style={{ background: ok ? "var(--green)" : "var(--red)" }}
    />
  );
}

function SectionHeader({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <div className="h-px flex-1" style={{ background: "var(--border)" }} />
      <span
        className="text-xs font-mono tracking-widest uppercase"
        style={{ color: "var(--muted)" }}
      >
        {children}
      </span>
      <div className="h-px flex-1" style={{ background: "var(--border)" }} />
    </div>
  );
}

function ClusterCard({
  ctx,
  selected,
  onClick,
}: {
  ctx: ClusterContext;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`cluster-card w-full text-left rounded-lg border p-3 ${
        selected ? "selected" : ""
      }`}
      style={{
        background: selected ? "rgba(0,212,255,0.08)" : "var(--card)",
        borderColor: selected ? "var(--accent)" : "var(--border)",
      }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-base">⎈</span>
          <span
            className="font-mono text-sm font-medium truncate max-w-[180px]"
            style={{ color: selected ? "var(--accent)" : "var(--text)" }}
          >
            {ctx.name}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {ctx.is_current && (
            <span
              className="text-xs font-mono px-2 py-0.5 rounded"
              style={{
                background: "rgba(0,255,136,0.1)",
                color: "var(--green)",
                border: "1px solid rgba(0,255,136,0.3)",
              }}
            >
              current
            </span>
          )}
          {selected && (
            <span style={{ color: "var(--accent)" }}>✓</span>
          )}
        </div>
      </div>
    </button>
  );
}

function InvestigationProgress({
  completedSteps,
  activeStep,
}: {
  completedSteps: InvestigationStep[];
  activeStep: InvestigationStep | null;
}) {
  return (
    <div
      className="rounded-xl border p-5 animate-fade-in"
      style={{ background: "var(--card)", borderColor: "var(--border)" }}
    >
      <div className="flex items-center gap-2 mb-4">
        <div
          className="w-2 h-2 rounded-full animate-pulse"
          style={{ background: "var(--accent)" }}
        />
        <span
          className="text-xs font-mono tracking-widest uppercase"
          style={{ color: "var(--accent)" }}
        >
          Investigation Running
        </span>
      </div>
      <div className="space-y-2">
        {STEPS.map((step) => {
          const isDone = completedSteps.includes(step.id);
          const isActive = activeStep === step.id;
          return (
            <div
              key={step.id}
              className="flex items-center gap-3 py-1"
            >
              <div className="w-5 text-center">
                {isDone ? (
                  <span style={{ color: "var(--green)" }}>✓</span>
                ) : isActive ? (
                  <span
                    className="inline-block w-4 h-4 border-2 border-t-transparent rounded-full animate-spin"
                    style={{ borderColor: "var(--accent)", borderTopColor: "transparent" }}
                  />
                ) : (
                  <span style={{ color: "var(--border)" }}>○</span>
                )}
              </div>
              <span
                className="font-mono text-sm"
                style={{
                  color: isDone
                    ? "var(--green)"
                    : isActive
                    ? "var(--accent)"
                    : "var(--muted)",
                }}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ConfidenceMeter({ value }: { value: number }) {
  const color =
    value >= 80
      ? "var(--green)"
      : value >= 60
      ? "var(--yellow)"
      : "var(--red)";

  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-mono" style={{ color: "var(--muted)" }}>
          Confidence
        </span>
        <span className="font-mono font-bold text-sm" style={{ color }}>
          {value}%
        </span>
      </div>
      <div
        className="w-full h-1.5 rounded-full overflow-hidden"
        style={{ background: "var(--border)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${value}%`, background: color }}
        />
      </div>
    </div>
  );
}

function DiagnosisCard({ diagnosis }: { diagnosis: InvestigationResponse["diagnosis"] }) {
  if (!diagnosis) return null;
  const isHealthy = diagnosis.root_cause === "No critical issues detected";

  return (
    <div
      className="rounded-xl border p-6 animate-slide-up"
      style={{
        background: "var(--card)",
        borderColor: isHealthy ? "rgba(0,255,136,0.3)" : "rgba(255,68,68,0.3)",
      }}
    >
      <div className="flex items-center gap-2 mb-5">
        <span className="text-lg">{isHealthy ? "🟢" : "🔴"}</span>
        <span
          className="text-xs font-mono tracking-widest uppercase"
          style={{ color: isHealthy ? "var(--green)" : "var(--red)" }}
        >
          {isHealthy ? "Cluster Healthy" : "Issue Detected"}
        </span>
      </div>

      <div className="space-y-5">
        {/* Root Cause */}
        <div>
          <div className="text-xs font-mono mb-1" style={{ color: "var(--muted)" }}>
            ROOT CAUSE
          </div>
          <div
            className="font-semibold text-base"
            style={{ color: isHealthy ? "var(--green)" : "var(--red)" }}
          >
            {diagnosis.root_cause}
          </div>
        </div>

        {/* Explanation */}
        <div>
          <div className="text-xs font-mono mb-1" style={{ color: "var(--muted)" }}>
            EXPLANATION
          </div>
          <div className="text-sm leading-relaxed" style={{ color: "var(--text)" }}>
            {diagnosis.explanation}
          </div>
        </div>

        {/* Fix */}
        <div>
          <div className="text-xs font-mono mb-1" style={{ color: "var(--muted)" }}>
            SUGGESTED FIX
          </div>
          <div className="text-sm leading-relaxed" style={{ color: "var(--text)" }}>
            {diagnosis.fix}
          </div>
        </div>

        {/* kubectl command */}
        <div>
          <div className="text-xs font-mono mb-2" style={{ color: "var(--muted)" }}>
            KUBECTL COMMAND
          </div>
          <div className="terminal-block">{diagnosis.kubectl_command}</div>
        </div>

        {/* Prevention */}
        <div>
          <div className="text-xs font-mono mb-1" style={{ color: "var(--muted)" }}>
            PREVENTION
          </div>
          <div
            className="text-sm leading-relaxed"
            style={{ color: "var(--muted)" }}
          >
            {diagnosis.prevention}
          </div>
        </div>

        {/* Confidence */}
        <ConfidenceMeter value={diagnosis.confidence} />
      </div>
    </div>
  );
}

function InvestigationSummary({ inv }: { inv: InvestigationResponse["investigation"] }) {
  if (!inv) return null;

  const stats = [
    {
      label: "Pods",
      value: `${inv.pods.total_pods}`,
      status: inv.pods.healthy,
      detail: inv.pods.summary,
    },
    {
      label: "Deployments",
      value: inv.deployments.healthy ? "OK" : `${inv.deployments.unhealthy_deployments.length} issue(s)`,
      status: inv.deployments.healthy,
      detail: inv.deployments.summary,
    },
    {
      label: "Events",
      value: `${inv.events.warning_count} warning(s)`,
      status: inv.events.warning_count === 0,
      detail: inv.events.summary,
    },
    {
      label: "Network",
      value: inv.network.issues_found ? "Issues" : "OK",
      status: !inv.network.issues_found,
      detail: inv.network.summary,
    },
  ];

  return (
    <div
      className="rounded-xl border p-5 animate-slide-up"
      style={{ background: "var(--card)", borderColor: "var(--border)" }}
    >
      <SectionHeader>Evidence Collected</SectionHeader>
      <div className="grid grid-cols-2 gap-3">
        {stats.map((s) => (
          <div
            key={s.label}
            className="rounded-lg p-3"
            style={{ background: "#060a14", border: "1px solid var(--border)" }}
          >
            <div className="flex items-center gap-2 mb-1">
              <StatusDot ok={s.status} />
              <span className="text-xs font-mono" style={{ color: "var(--muted)" }}>
                {s.label}
              </span>
            </div>
            <div className="font-mono text-sm font-semibold" style={{ color: "var(--text)" }}>
              {s.value}
            </div>
            <div className="text-xs mt-1 leading-tight" style={{ color: "var(--muted)" }}>
              {s.detail}
            </div>
          </div>
        ))}
      </div>

      {/* Problematic pods detail */}
      {inv.pods.problematic_pods.length > 0 && (
        <div className="mt-4">
          <div className="text-xs font-mono mb-2" style={{ color: "var(--muted)" }}>
            PROBLEMATIC PODS
          </div>
          <div className="space-y-1.5">
            {inv.pods.problematic_pods.map((pod, i) => (
              <div
                key={i}
                className="flex items-center justify-between text-xs font-mono px-3 py-2 rounded"
                style={{ background: "rgba(255,68,68,0.05)", border: "1px solid rgba(255,68,68,0.2)" }}
              >
                <span style={{ color: "var(--text)" }}>{pod.name}</span>
                <div className="flex items-center gap-3">
                  <span style={{ color: "var(--muted)" }}>{pod.namespace}</span>
                  <span
                    className="px-1.5 py-0.5 rounded text-xs"
                    style={{
                      background: "rgba(255,68,68,0.15)",
                      color: "var(--red)",
                    }}
                  >
                    {pod.status}
                  </span>
                  {pod.restart_count > 0 && (
                    <span style={{ color: "var(--yellow)" }}>
                      ↻ {pod.restart_count}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Investigation History ────────────────────────────────────────────────────

interface HistoryEntry {
  id: string;
  timestamp: string;
  context: string;
  root_cause: string;
  confidence: number;
  status: "success" | "error";
}

function HistoryTable({ history }: { history: HistoryEntry[] }) {
  if (history.length === 0) return null;

  return (
    <div
      className="rounded-xl border p-5 animate-fade-in"
      style={{ background: "var(--card)", borderColor: "var(--border)" }}
    >
      <SectionHeader>Recent Investigations</SectionHeader>
      <div className="space-y-2">
        {history.map((entry) => (
          <div
            key={entry.id}
            className="flex items-center justify-between py-2 px-3 rounded-lg text-xs font-mono"
            style={{ background: "#060a14", border: "1px solid var(--border)" }}
          >
            <div className="flex items-center gap-3 min-w-0">
              <StatusDot ok={entry.status === "success"} />
              <span className="truncate max-w-[180px]" style={{ color: "var(--text)" }}>
                {entry.root_cause}
              </span>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <span style={{ color: "var(--muted)" }}>{entry.context}</span>
              <span style={{ color: entry.confidence >= 80 ? "var(--green)" : "var(--yellow)" }}>
                {entry.confidence}%
              </span>
              <span style={{ color: "var(--muted)" }}>
                {new Date(entry.timestamp).toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Home() {
  const [clusters, setClusters] = useState<ClusterContext[]>([]);
  const [selectedContext, setSelectedContext] = useState<string | null>(null);
  const [clustersError, setClustersError] = useState<string | null>(null);
  const [isLoadingClusters, setIsLoadingClusters] = useState(true);

  const [isInvestigating, setIsInvestigating] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<InvestigationStep[]>([]);
  const [activeStep, setActiveStep] = useState<InvestigationStep | null>(null);

  const [result, setResult] = useState<InvestigationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  // Load clusters on mount
  useEffect(() => {
    (async () => {
      try {
        const data = await fetchClusters();
        setClusters(data.contexts);
        // Auto-select current context
        const current = data.contexts.find((c) => c.is_current);
        if (current) setSelectedContext(current.name);
        else if (data.contexts.length > 0) setSelectedContext(data.contexts[0].name);
      } catch (err) {
        setClustersError(
          "Could not connect to backend. Make sure the FastAPI server is running on port 8000."
        );
      } finally {
        setIsLoadingClusters(false);
      }
    })();
  }, []);

  // Simulate step-by-step progress (visual feedback while real API runs)
  const runProgressAnimation = useCallback(async () => {
    const steps = STEPS.slice(0, -1); // all except "done"
    for (const step of steps) {
      setActiveStep(step.id);
      await new Promise((r) => setTimeout(r, step.duration));
      setCompletedSteps((prev) => [...prev, step.id]);
    }
    setActiveStep("done");
    setCompletedSteps((prev) => [...prev, "done"]);
  }, []);

  const handleInvestigate = async () => {
    if (!selectedContext) return;
    setIsInvestigating(true);
    setResult(null);
    setError(null);
    setCompletedSteps([]);
    setActiveStep(null);

    // Start animation and API call in parallel
    const [_, response] = await Promise.all([
      runProgressAnimation(),
      runInvestigation(selectedContext).catch((err) => ({
        status: "error" as const,
        context: selectedContext,
        error: err?.response?.data?.detail || err?.message || "Investigation failed.",
      })),
    ]);

    const res = response as InvestigationResponse;
    setResult(res);
    setIsInvestigating(false);

    // Save to history
    if (res.diagnosis || res.error) {
      setHistory((prev) => [
        {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          context: selectedContext,
          root_cause: res.diagnosis?.root_cause || res.error || "Unknown",
          confidence: res.diagnosis?.confidence ?? 0,
          status: res.status,
        },
        ...prev.slice(0, 9), // keep last 10
      ]);
    }
  };

  const canInvestigate = selectedContext && !isInvestigating;

  return (
    <div className="min-h-screen" style={{ background: "var(--bg)" }}>
      {/* ── Header ── */}
      <header
        className="border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10 backdrop-blur-sm"
        style={{
          borderColor: "var(--border)",
          background: "rgba(10,14,26,0.9)",
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-sm"
            style={{ background: "rgba(0,212,255,0.15)", border: "1px solid rgba(0,212,255,0.3)" }}
          >
            ⎈
          </div>
          <div>
            <div className="font-semibold text-sm" style={{ color: "var(--text)" }}>
              AI Kubernetes Agent
            </div>
            <div className="text-xs font-mono" style={{ color: "var(--muted)" }}>
              Senior SRE Intelligence
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div
            className="w-2 h-2 rounded-full"
            style={{ background: isInvestigating ? "var(--yellow)" : "var(--green)" }}
          />
          <span className="text-xs font-mono" style={{ color: "var(--muted)" }}>
            {isInvestigating ? "investigating" : "ready"}
          </span>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8 space-y-6">

        {/* ── Cluster Selector ── */}
        <section>
          <SectionHeader>Select Cluster</SectionHeader>

          {isLoadingClusters ? (
            <div className="text-center py-8">
              <div
                className="inline-block w-6 h-6 border-2 border-t-transparent rounded-full animate-spin mb-3"
                style={{ borderColor: "var(--accent)", borderTopColor: "transparent" }}
              />
              <div className="text-sm font-mono" style={{ color: "var(--muted)" }}>
                Reading kubeconfig...
              </div>
            </div>
          ) : clustersError ? (
            <div
              className="rounded-xl border p-5 text-sm"
              style={{
                background: "rgba(255,68,68,0.05)",
                borderColor: "rgba(255,68,68,0.3)",
                color: "var(--red)",
              }}
            >
              <div className="font-semibold mb-1">⚠ Backend Unreachable</div>
              <div className="text-xs" style={{ color: "var(--muted)" }}>
                {clustersError}
              </div>
            </div>
          ) : clusters.length === 0 ? (
            <div
              className="rounded-xl border p-5 text-center"
              style={{ borderColor: "var(--border)", color: "var(--muted)" }}
            >
              <div className="text-2xl mb-2">⎈</div>
              <div className="text-sm font-mono">No kubeconfig contexts found.</div>
              <div className="text-xs mt-1">
                Run{" "}
                <code
                  className="px-1.5 py-0.5 rounded font-mono text-xs"
                  style={{ background: "var(--card)", color: "var(--accent)" }}
                >
                  kubectl config get-contexts
                </code>{" "}
                to verify.
              </div>
            </div>
          ) : (
            <div className="grid gap-2">
              {clusters.map((ctx) => (
                <ClusterCard
                  key={ctx.name}
                  ctx={ctx}
                  selected={selectedContext === ctx.name}
                  onClick={() => setSelectedContext(ctx.name)}
                />
              ))}
            </div>
          )}
        </section>

        {/* ── Investigate Button ── */}
        {clusters.length > 0 && (
          <section className="text-center">
            <button
              onClick={handleInvestigate}
              disabled={!canInvestigate}
              className="relative px-10 py-4 rounded-xl font-mono font-semibold text-sm transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: canInvestigate
                  ? "rgba(0,212,255,0.15)"
                  : "var(--card)",
                border: `1px solid ${canInvestigate ? "var(--accent)" : "var(--border)"}`,
                color: canInvestigate ? "var(--accent)" : "var(--muted)",
                boxShadow: canInvestigate ? "0 0 30px rgba(0,212,255,0.15)" : "none",
              }}
            >
              {isInvestigating ? (
                <span className="flex items-center gap-2">
                  <span
                    className="inline-block w-4 h-4 border-2 border-t-transparent rounded-full animate-spin"
                    style={{ borderColor: "var(--accent)", borderTopColor: "transparent" }}
                  />
                  Investigating {selectedContext}...
                </span>
              ) : (
                `⎈ Investigate ${selectedContext || "Cluster"}`
              )}
            </button>
            {selectedContext && (
              <div className="mt-2 text-xs font-mono" style={{ color: "var(--muted)" }}>
                Target: <span style={{ color: "var(--text)" }}>{selectedContext}</span>
              </div>
            )}
          </section>
        )}

        {/* ── Investigation Progress ── */}
        {isInvestigating && (
          <InvestigationProgress
            completedSteps={completedSteps}
            activeStep={activeStep}
          />
        )}

        {/* ── Error State ── */}
        {error && !isInvestigating && (
          <div
            className="rounded-xl border p-5 animate-fade-in"
            style={{
              background: "rgba(255,68,68,0.05)",
              borderColor: "rgba(255,68,68,0.3)",
            }}
          >
            <div className="font-semibold text-sm mb-2" style={{ color: "var(--red)" }}>
              ⚠ Investigation Failed
            </div>
            <div className="terminal-block text-xs" style={{ borderLeftColor: "var(--red)" }}>
              {error}
            </div>
            <div className="mt-3 text-xs" style={{ color: "var(--muted)" }}>
              Verify: kubeconfig path · cluster access · kubectl permissions
            </div>
          </div>
        )}

        {/* ── API Error from response ── */}
        {result?.status === "error" && result?.error && !isInvestigating && (
          <div
            className="rounded-xl border p-5 animate-fade-in"
            style={{
              background: "rgba(255,68,68,0.05)",
              borderColor: "rgba(255,68,68,0.3)",
            }}
          >
            <div className="font-semibold text-sm mb-2" style={{ color: "var(--red)" }}>
              ⚠ Investigation Error
            </div>
            <div className="terminal-block text-xs" style={{ borderLeftColor: "var(--red)" }}>
              {result.error}
            </div>
          </div>
        )}

        {/* ── Results ── */}
        {result?.status === "success" && !isInvestigating && (
          <>
            {result.diagnosis && <DiagnosisCard diagnosis={result.diagnosis} />}
            {result.investigation && <InvestigationSummary inv={result.investigation} />}
          </>
        )}

        {/* ── History ── */}
        <HistoryTable history={history} />

      </main>

      {/* ── Footer ── */}
      <footer
        className="border-t mt-16 py-4 text-center"
        style={{ borderColor: "var(--border)" }}
      >
        <span className="text-xs font-mono" style={{ color: "var(--muted)" }}>
          AI Kubernetes Agent · Powered by OpenRouter ·{" "}
          <span style={{ color: "var(--accent)" }}>Senior SRE Intelligence</span>
        </span>
      </footer>
    </div>
  );
}
