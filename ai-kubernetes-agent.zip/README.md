# ⎈ AI Kubernetes Agent

AI-powered Kubernetes troubleshooting. Behaves like a **Senior SRE** — investigates your cluster, finds root causes, and tells you exactly how to fix them.

---

## Architecture

```
Browser Dashboard
      ↓
Next.js Frontend (port 3000)
      ↓
FastAPI Backend (port 8000)
      ↓
Kubernetes Investigation Layer
  ├── Pod Inspector
  ├── Logs Collector
  ├── Events Analyzer
  ├── Deployment Inspector
  └── Network Inspector
      ↓
AI Kubernetes Agent
  ├── Prompt Builder
  ├── LLM Client (OpenRouter)
  └── Root Cause Analyzer
      ↓
Diagnosis: Root Cause + Fix + Confidence
```

---

## Quick Start

### 1. Set up environment

```bash
cp backend/.env.example backend/.env
```

Edit `backend/.env`:
```env
OPENROUTER_API_KEY=sk-or-v1-your-key-here
OPENROUTER_MODEL=deepseek/deepseek-r1-0528
KUBECONFIG_PATH=~/.kube/config
```

### 2. Run with Docker Compose

```bash
docker compose up --build
```

Open:
- **Dashboard**: http://localhost:3000
- **API**: http://localhost:8000/health

### 3. Or run locally (development)

**Backend:**
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

---

## How it works

1. **Dashboard loads** → Reads your `~/.kube/config` and shows all clusters
2. **Select a cluster** → Click any cluster card
3. **Click Investigate** → Watch live progress as evidence is collected
4. **AI Reasoning** → OpenRouter LLM correlates pods + logs + events + deployments
5. **Diagnosis** → Root cause, explanation, fix, kubectl command, confidence score

---

## API Endpoints

```
GET  /health         → Health check
GET  /clusters       → List kubeconfig contexts
POST /investigate    → Run investigation + AI diagnosis
```

**POST /investigate body:**
```json
{
  "context": "my-cluster",
  "namespace": "all"
}
```

**Response:**
```json
{
  "status": "success",
  "context": "my-cluster",
  "diagnosis": {
    "root_cause": "DATABASE_URL environment variable missing",
    "explanation": "...",
    "fix": "...",
    "kubectl_command": "kubectl edit deployment payment-service",
    "prevention": "...",
    "confidence": 94
  }
}
```

---

## Testing with failure scenarios

Apply test scenarios to your cluster:

```bash
# Scenario 1 — CrashLoopBackOff
kubectl apply -f docs/test-scenarios.yaml

# Check what broke
kubectl get pods -A

# Then investigate via the dashboard
```

**Test scenarios included:**
| Scenario | Root Cause |
|----------|-----------|
| `payment-service` | Missing `DATABASE_URL` env var → CrashLoopBackOff |
| `api-gateway` | Wrong image tag → ImagePullBackOff |
| `data-processor` | 20Mi memory limit too low → OOMKilled |
| `user-service` | Service selector `user-svc` ≠ pod label `user-service` |

**Clean up after testing:**
```bash
kubectl delete deployment payment-service api-gateway data-processor user-service
kubectl delete service user-service
```

---

## Project structure

```
ai-kubernetes-agent/
├── backend/
│   ├── main.py                    # FastAPI app + endpoints
│   ├── core/
│   │   ├── config.py              # Settings (env vars)
│   │   └── logger.py              # Loguru setup
│   ├── kubernetes/
│   │   ├── kubectl_executor.py    # Safe kubectl runner
│   │   ├── pod_inspector.py       # Pod status detection
│   │   ├── logs_collector.py      # Error log filtering
│   │   ├── events_analyzer.py     # Warning/critical events
│   │   ├── deployment_inspector.py
│   │   └── network_inspector.py
│   ├── ai/
│   │   ├── prompt_builder.py      # SRE system prompt
│   │   ├── llm_client.py          # OpenRouter HTTPX client
│   │   └── root_cause_analyzer.py # Orchestrates AI reasoning
│   ├── services/
│   │   └── investigation_service.py
│   └── models/
│       └── schemas.py             # Pydantic models
├── frontend/
│   └── src/app/page.tsx           # Dashboard (cluster selector + diagnosis)
├── docs/
│   └── test-scenarios.yaml        # 4 failure scenarios for testing
└── docker-compose.yml
```
